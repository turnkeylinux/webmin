desc_pl=Wysy�anie i pobieranie
longdesc_pl=Wysy�anie wielu plik�w na serwer i pobieranie z i na serwer z URL przez harmonogram lub natychmiast.
