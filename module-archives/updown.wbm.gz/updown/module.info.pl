desc_pl=Wysyłanie i pobieranie
longdesc_pl=Wysyłanie wielu plików na serwer i pobieranie z i na serwer z URL przez harmonogram lub natychmiast.
