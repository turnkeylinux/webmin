desc_cs=Nahrávání souborů
