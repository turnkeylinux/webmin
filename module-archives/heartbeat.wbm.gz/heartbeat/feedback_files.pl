
do 'heartbeat-lib.pl';

sub feedback_files
{
return ( $ha_cf, $haresources, $authkeys, $resource_d );
}

1;

