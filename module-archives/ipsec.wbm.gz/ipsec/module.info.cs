desc_cs=Konfiguace IPsec VPN
