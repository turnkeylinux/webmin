line1=Opcje konfigurowalne,11
auto=Automatycznie do��cz pliki dziennika z,2,apache-Apache,squid-Squid,proftpd-ProFTPd,wuftpd-WUFTPd
naked=Doda� nag��wek i stopk� webmina do raportu Webalizera?,1,0-Tak,1-Nie
skip_old=Uwzgl�dni� stare (rotated) pliki dziennika (log�w)?,1,0-Tak,1-Nie
line2=Konfiguracja systemu,11
webalizer=�cie�ka do komendy webalizer,0
webalizer_conf=�cie�ka do pliku konfiguracyjnego webalizera,0
alt_conf=Przyk�adowy plik konfiguracyjny webalizera,3,Brak
