auto=Automaticky zahrnout log soubory z,2,apache-Apache,squid-Squid
webalizer=Cesta k příkazu webalizeru,0
webalizer_conf=Cesta ke konfiguračnímu souboru webalizeru,0
alt_conf=Vzor webalizer konfiguračního souboru,3,Nic
