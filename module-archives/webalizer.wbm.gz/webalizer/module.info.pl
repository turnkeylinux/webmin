desc_pl=Webalizer - Analiza log�w
longdesc_pl=Generuje raporty z serwera www, proxy i FTP
