desc_pl=Perl - modu�y (CPAN)
longdesc_pl=Instaluj nowe modu�y Perla i sprawd� jakie ju� s� zainstalowane.
