desc_pl=Perl - moduły (CPAN)
longdesc_pl=Instaluj nowe moduły Perla i sprawdź jakie już są zainstalowane.
