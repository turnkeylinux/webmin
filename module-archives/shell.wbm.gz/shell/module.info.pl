desc_pl=Linia poleceń
