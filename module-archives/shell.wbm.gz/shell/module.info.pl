desc_pl=Linia polece�
