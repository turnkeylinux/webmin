desc_cs=Příkazový řádek
