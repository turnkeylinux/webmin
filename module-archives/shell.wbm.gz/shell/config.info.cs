clear_envs=Vynechat proměnné prostředí Webminu u příkazů v řádce?,1,0-Ano,1-Ne
