# shell-lib.pl

do '../web-lib.pl';
&init_config();
do '../ui-lib.pl';

1;

