php_ini=Pliki globalnej konfiguracji PHP<br>(W formacie <i>nazwa pliku</i>=<i>opis</i>),9,70,5,\t
