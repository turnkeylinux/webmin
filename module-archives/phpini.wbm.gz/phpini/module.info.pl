desc_pl=Konfiguracja PHP
longdesc_pl=Konfiguruj ustawienia PHP na ca�ym serwerze lub na wybranych wirtualnych serwerach Apache.
