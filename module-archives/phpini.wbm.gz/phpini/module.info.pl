desc_pl=Konfiguracja PHP
longdesc_pl=Konfiguruj ustawienia PHP na całym serwerze lub na wybranych wirtualnych serwerach Apache.
