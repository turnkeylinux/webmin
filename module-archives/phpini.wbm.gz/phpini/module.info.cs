desc_cs=PHP konfigurace
