date_subs=Provést <tt>strftime</tt> náhradu v cíli záloh?,1,1-Ano,0-Ne
from_addr=Adresa Od: pro e-mailové zprávy,3,webmin@hostname
