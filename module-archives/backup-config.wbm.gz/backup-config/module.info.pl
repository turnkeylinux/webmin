desc_pl=Kopia plików konfiguracyjnych
longdesc_pl=Ręczne lub zaplanowane tworzenie i przywracanie kopii zapasowych plików konfiguracyjnych modułów zarządzanych przez Webmina.
