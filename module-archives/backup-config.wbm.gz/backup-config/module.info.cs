desc_cs=Záloha konfiguračních souborů
