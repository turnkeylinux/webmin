date_subs=Wykona� zast�powanie <tt>strftime</tt> miejsc docelowych kopii zapasowej?,1,1-Tak,0-Nie
from_addr=Od: adres dla wiadomo�ci email,3,webmin@hostname
