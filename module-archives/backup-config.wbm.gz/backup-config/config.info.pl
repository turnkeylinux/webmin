date_subs=Wykonać zastępowanie <tt>strftime</tt> miejsc docelowych kopii zapasowej?,1,1-Tak,0-Nie
webmin_subs=Uczynić zmienną Webmina jako miejsce docelowe kopii zapasowych?,1,1-Tak,0-Nie
from_addr=Od: adres dla wiadomości email,3,webmin@hostname
