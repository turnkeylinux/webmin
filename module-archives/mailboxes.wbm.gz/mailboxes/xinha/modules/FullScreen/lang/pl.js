// I18N constants
// LANG: "pl", ENCODING: UTF-8
// translated: Krzysztof Kotowicz, koto1sa@o2.pl, http://www.eskot.krakow.pl/portfolio
{
  "Maximize/Minimize Editor": "Maksymalizuj/minimalizuj edytor"
};
