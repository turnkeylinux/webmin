line1=Nastavení konfigurace,11
install=Instalace GRUB na disk/oddíl,0
line2=Konfigurace systému,11
menu_file=Konfigurační soubor GRUB menu,0
grub_path=Cesta ke spuštěči GRUBu,0
device_map=Soubor pro mapování názvů zařízení,3,Získat z GRUB
