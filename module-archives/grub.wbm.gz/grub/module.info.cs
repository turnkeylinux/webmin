desc_cs=Zavaděč systému GRUB
