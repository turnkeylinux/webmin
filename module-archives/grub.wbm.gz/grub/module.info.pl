desc_pl=Inicjator systemu GRUB
