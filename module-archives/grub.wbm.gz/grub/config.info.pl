menu_file=Plik konfiguracyjny manu GRUBa,0
grub_path=Scie�ka do programu <tt>grub</tt>,0
install=Instalowa� GRUBa na dysku/partycji,0
