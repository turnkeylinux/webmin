install=Instalować GRUBa na dysku/partycji,0
menu_file=Plik konfiguracyjny manu GRUBa,0
grub_path=Scieżka do programu <tt>grub</tt>,0
