desc_pl=SSH - Serwer
