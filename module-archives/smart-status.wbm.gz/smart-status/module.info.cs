desc_cs=SMART stav disků
