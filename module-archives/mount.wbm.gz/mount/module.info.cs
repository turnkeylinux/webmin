desc_cs=Lokální a síťové systémy souborů
