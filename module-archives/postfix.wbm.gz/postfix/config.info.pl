postfix_control_command=Pełna ścieżka do polecenia kontrolnego Postfiksa,0
postfix_config_command=Pełna ścieżka do polecenia konfiguracyjnego Postfiksa,0
postfix_config_file=Pełna ścieżka do pliku konfiguracyjnego Postfiksa,0
postfix_aliases_table_command=Pełna ścieżka do polecenia tworzącego aliasy Postfiksa,0
postfix_newaliases_command=Pełna ścieżka do polecenia "newaliases" (zgodność z&nbsp;Sendmailem),0
postfix_lookup_table_command=Pełna ścieżka do polecenia zarządzającego tablicami przeszukiwania Postfiksa (`postmap'),0
