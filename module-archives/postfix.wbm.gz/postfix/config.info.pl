postfix_control_command=Pe�na �cie�ka do polecenia kontrolnego Postfiksa,0
postfix_config_command=Pe�na �cie�ka do polecenia konfiguracyjnego Postfiksa,0
postfix_config_file=Pe�na �cie�ka do pliku konfiguracyjnego Postfiksa,0
postfix_aliases_table_command=Pe�na �cie�ka do polecenia tworz�cego aliasy Postfiksa,0
postfix_newaliases_command=Pe�na �cie�ka do polecenia &quot;newaliases&quot; (zgodno�� z&nbsp;Sendmailem),0
postfix_lookup_table_command=Pe�na �cie�ka do polecenia zarz�dzaj�cego tablicami przeszukiwania Postfiksa (`postmap'),0
