desc_pl=DHCP - Serwer
longdesc_pl=Zarz�dzaj udost�pnianiem sieci, podsieci, host�w i grup dla ISC DHCPD.
