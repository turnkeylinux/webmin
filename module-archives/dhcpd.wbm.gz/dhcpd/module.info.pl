desc_pl=DHCP - Serwer
longdesc_pl=Zarządzaj udostępnianiem sieci, podsieci, hostów i grup dla ISC DHCPD.
