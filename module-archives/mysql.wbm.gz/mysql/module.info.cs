desc_cs=Databázový server MySQL
