desc_cs=MON - Monitorování služeb
