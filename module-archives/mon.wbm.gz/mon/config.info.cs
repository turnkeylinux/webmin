line2=Konfigurace systému,11
pid_file=Úplná cesta MON pid souboru,0
cfbasedir=Úplná cesta ke všem uloženým kongiguračním souborům (jako mon.cf,auth.cf apod...),0
mon_cgi=Úplná cesta k MON cgi programu,0
start_cmd=Příkaz pro spuštění MON,0
stop_cmd=Příkaz pro ukončení MON,3,Zabít proces
restart_cmd=Příkaz pro restartování MON,3,Poslat HUP signál
