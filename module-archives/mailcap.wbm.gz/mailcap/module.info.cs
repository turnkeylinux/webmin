desc_cs=Programy MIME Type
