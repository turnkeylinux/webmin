desc_pl=Typy programów MIME
longdesc_pl=Edytuj plik /etc/mailcap, który zawiera mapę typów MIME i programów do ich obsługi
