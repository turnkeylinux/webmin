mailcap=Plik typów programów MIME,0
