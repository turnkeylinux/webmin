desc_pl=Zaplanowane Funkcje Webmina
longdesc_pl=Okre�l funkcje Webmina, kt�re maj� by� uruchamiane wed�ug regularnego harmonogramu przez serwer Webmin
