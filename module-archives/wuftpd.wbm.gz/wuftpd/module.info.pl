desc_pl=WU-FTP - serwer
longdesc_pl=Konfiguracja dostępu, anonimowego FTP i innych opcji dla WU-FTPd.
