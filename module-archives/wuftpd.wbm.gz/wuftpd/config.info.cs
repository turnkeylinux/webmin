line2=Konfigurace systému,11
ftpd_path=Úplná cesta k wuftpd,0
ftpaccess=FÚplná cesta k souboru ftpaccess,0
ftpconversions=Úplná cesta k souboru ftpconversions,0
ftpgroups=Úplná cesta k souboru ftpgroups,0
ftphosts=Úplná cesta k souboru ftphosts,0
ftpusers=Úplná cesta k souboru ftpusers,0
pid_file=PID soubor FTP serveru,0
