desc_cs=Stav systému a serverů
