desc_pl=Stan systemu i serwerów
longdesc_pl=Wyświetl stan usług na twoim i zdalnym systemie.
