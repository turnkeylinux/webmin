desc_pl=Bacula - system kopii zapasowej
longdesc_pl=Skonfiguruj Bacula do przeprowadzania kopii zapasowej i przywracania ręcznie lub według harmonogramu na jednym lub wielu systemach.
