proftpd_conf=�cie�ka do pliku konfiguracyjnego ProFTPD,0
proftpd_path=�cie�ka do programu ProFTPD,0
pid_file=�cie�ka do pliku z numerem PID ProFTPD,0
ftpusers=�cie�ka do pliku <tt>ftpusers</tt>,0
start_cmd=Polecenie uruchamiaj�ce ProFTPD,3,Automatycznie
