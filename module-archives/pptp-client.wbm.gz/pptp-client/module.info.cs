desc_cs=PPTP VPN klient
