hosts_allow=Plik dozwolonych host�w,0
hosts_deny=Plik zabronionych host�w,0
inetd_services=Pobra� mo�liwe us�ugi z inetd?,1,1-Tak,0-Nie
