hosts_allow=Plik dozwolonych hostów,0
hosts_deny=Plik zabronionych hostów,0
inetd_services=Pobrać możliwe usługi z inetd?,1,1-Tak,0-Nie
