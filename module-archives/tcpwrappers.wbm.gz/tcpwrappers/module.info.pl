desc_pl=TCP - Wrappery
longdesc_pl=Konfiruracja wrapper�w TCP - kontrola dost�pu sieciowego
