desc_pl=TCP - Wrappery
longdesc_pl=Konfiruracja wrapperów TCP - kontrola dostępu sieciowego
