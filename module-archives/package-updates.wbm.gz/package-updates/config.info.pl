cache_time=Ilość godzin pamięci podręcznej aktualizacji i dostępnych pakietów,3,Bez pamięci podręcznej
