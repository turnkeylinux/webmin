desc_pl=Aktualizacja pakiet�w oprogramowania
longdesc_pl=Wy�wietla dost�pne aktualizacje pakiet�w z YUM, APT lub innego systemowego menad�era pakiet�w
