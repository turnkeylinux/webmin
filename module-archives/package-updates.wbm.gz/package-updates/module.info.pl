desc_pl=Aktualizacja pakietów oprogramowania
longdesc_pl=Wyświetla dostępne aktualizacje pakietów z YUM, APT lub innego systemowego menadżera pakietów
