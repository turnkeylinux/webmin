desc_pl=PostgreSQL - Serwer baz danych
