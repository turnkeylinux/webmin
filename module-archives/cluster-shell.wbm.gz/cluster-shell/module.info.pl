desc_pl=Klaster - Polecenia powłoki (Shell)
longdesc_pl=Uruchamiaj polecenia na wielu serwerach równocześnie.
