htaccess=Název souboru voleb Apache,0
htpasswd=Název souboru pro uživatele,0
htgroups=Název souboru pro skupiny,0
sort=Třídit uživatele podle,1,1-Uživatelského jména,0-Pořadí v souboru
md5=Nabídnout volbu pro MD5 šifrování?,1,1-Ano,0-Ne
sha1=Nabídnout volbu pro SHA1 šifrování?,1,1-Ano,0-Ne
digest=Nabídnout volbu pro digest šifrování?,1,1-Ano,0-Ne
extra_directives=Extra directivy do include v .htaccess,9,0,0,\t
