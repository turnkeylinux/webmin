desc_cs=Blokování web adresářů
