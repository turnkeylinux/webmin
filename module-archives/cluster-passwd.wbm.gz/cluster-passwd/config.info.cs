max_users=Maximální počet zobrazených uživatelů,0
input_type=Typ pro výběr uživatelů,1,1-Seznam,0-Textové pole
sort_mode=Třídit uživatele podle,1,0-Pořadí v souboru,1-Uživatelského jména
