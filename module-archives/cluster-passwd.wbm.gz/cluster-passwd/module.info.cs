desc_cs=Cluster - Změna hesel
