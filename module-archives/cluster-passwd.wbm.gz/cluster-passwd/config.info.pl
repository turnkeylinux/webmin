max_users=Maksymalna ilość użytkowników do wyświetlenia,0
input_type=Typ zaznaczenia użytkownika,1,1-Lista,0-Pole tekstowe
sort_mode=Sortuj użytkowników według,1,0-Kolejności w pliku,1-Nazwy użytkownika
