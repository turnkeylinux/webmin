desc_pl=Klaster - Zmiana haseł
longdesc_pl=Zmień hasła na wielu serwerach w klastrze Webmina równocześnie.
