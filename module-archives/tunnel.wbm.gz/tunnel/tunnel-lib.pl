# tunnel-lib.pl
# Common functions for the HTTP-tunnel module

do '../web-lib.pl';
&init_config();
do '../ui-lib.pl';

1;

