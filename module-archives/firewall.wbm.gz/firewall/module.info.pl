desc_pl=Firewall Linuksa
longdesc_pl=Konfiguracja firewall linuksa używając iptables. Pozwala na edycję wszystkich tabel, reguł i opcji.
