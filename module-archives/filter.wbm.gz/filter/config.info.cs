virtualmin_spam=Úplná cesta pro kontrolní program spamů uživatele ve Virtualminu,3,Není nainstalován,40
virtualmin_config=Úplná cesta pro konfigurační adresář Virtualminu,3,Není nainstalován
warn_procmail=Zobrazit varování v případě&#44; že není nainstalován Procmail?,1,1-Ano,0-Ne
alias_files=Úplná cesta pro hlavní soubory s aliasy,9,40,3,\t
