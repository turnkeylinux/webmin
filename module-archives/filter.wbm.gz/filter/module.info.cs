desc_cs=Filtrování a přeposílání pošty
