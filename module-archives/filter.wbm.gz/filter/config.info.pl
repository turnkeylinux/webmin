virtualmin_spam=Pe�na �cie�ka do spamu u�ytkownika Virtualmina,3,Nie zainstalowany,40
virtualmin_config=Pe�na �cie�ka do folderu konfiguracji Virtualmina,3,Nie zainstalowany
warn_procmail=Wy�wietla� ostrze�enie je�eli Procmail nie jest zainstalowany?,1,1-Tak,0-Nie
forward_procmail=Utworzy� plik .forward przy uruchomieniu procmail?,1,1-Tak,0-Nie
alias_files=Pe�na �cie�ka do plik�w globalnych alias�w,9,40,3,\t
reply_min=Minimalny odst�p mi�dzy wysy�aniem auto odpowiedzi,3,Bez odst�pu,5,,minut
reply_force=Wymusi� u�ycie minimalnego interwa�u auto&#45;odpowiedzi?,1,1-Tak,0-Nie
