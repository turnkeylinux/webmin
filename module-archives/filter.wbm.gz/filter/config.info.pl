virtualmin_spam=Pełna ścieżka do spamu użytkownika Virtualmina,3,Nie zainstalowany,40
virtualmin_config=Pełna ścieżka do folderu konfiguracji Virtualmina,3,Nie zainstalowany
warn_procmail=Wyświetlać ostrzeżenie jeżeli Procmail nie jest zainstalowany?,1,1-Tak,0-Nie
forward_procmail=Utworzyć plik .forward przy uruchomieniu procmail?,1,1-Tak,0-Nie
alias_files=Pełna ścieżka do plików globalnych aliasów,9,40,3,\t
reply_min=Minimalny odstęp między wysyłaniem auto odpowiedzi,3,Bez odstępu,5,,minut
reply_force=Wymusić użycie minimalnego interwału auto&#45;odpowiedzi?,1,1-Tak,0-Nie
