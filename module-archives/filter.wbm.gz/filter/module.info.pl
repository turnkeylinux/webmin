desc_pl=Filtry i przekierowanie e-maili
longdesc_pl=Twórz reguły filtrów i przekierowania przychodzących e-maili.
