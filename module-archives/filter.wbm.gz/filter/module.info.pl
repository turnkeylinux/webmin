desc_pl=Filtry i przekierowanie e-maili
longdesc_pl=Tw�rz regu�y filtr�w i przekierowania przychodz�cych e-maili.
