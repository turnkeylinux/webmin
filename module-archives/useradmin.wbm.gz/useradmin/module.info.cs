desc_cs=Uživatelé a skupiny
