desc_pl=Użytkownicy i grupy
longdesc_pl=Twórz i edytuj użytkowników i grupy Unix z plików /etc/passwd i /etc/group.
