desc_pl=U�ytkownicy i&nbsp;grupy
longdesc_pl=Tw�rz i edytuj u�ytkownik�w i grupy Unix z plik�w /etc/passwd i /etc/group.
