desc_pl=Us�ugi sieciowe
longdesc_pl=Edytuj serwery obs�ugiwane przez xinetd, w zast�pstwie dla inetd.
