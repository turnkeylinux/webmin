desc_pl=Usługi sieciowe
longdesc_pl=Edytuj serwery obsługiwane przez xinetd, w zastępstwie dla inetd.
