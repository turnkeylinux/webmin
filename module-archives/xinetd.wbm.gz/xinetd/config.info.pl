xinetd_conf=Plik konfiguracyjny Xinetd,0
protocols_file=Plik protoko��w sieciowych,0
pid_file=Scie�ka do pliku z&nbsp;numerem PID Xinetd,0
start_cmd=Polecenie uruchamiaj�ce,0
