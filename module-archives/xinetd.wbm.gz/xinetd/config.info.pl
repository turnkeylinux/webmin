line2=Konfiguracja systemu,11
xinetd_conf=Plik konfiguracyjny Xinetd,0
protocols_file=Plik protokołów sieciowych,0
pid_file=Ścieżka do pliku z numerem PID Xinetd,3,Brak (wyszukaj w procesach)
start_cmd=Polecenie uruchamiające xinetd,0
add_dir=Dodaj nowe usługi do,15,add_dir
lookup_servs=Wyszukiwać numery portów na stronie głównej?,1,1-Tak,0-Nie
