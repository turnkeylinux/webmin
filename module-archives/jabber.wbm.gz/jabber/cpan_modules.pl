
require 'jabber-lib.pl';

sub cpan_recommended
{
return ( "XML::Parser", "XML::Generator" );
}

