desc_cs=Jabber IM server
