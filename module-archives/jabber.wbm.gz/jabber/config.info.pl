line2=Konfiguracja systemu,11
jabber_config=Plik konfiguracji XML Jabber,0
jabber_dir=Bazowy katalog Jabber,0
jabber_daemon=Ścieżka do programu serwera jabber,3,W bazowym katalogu
jabber_spool=Katalog hostów Jabber,3,W bazowym katalogu
jabber_lib=Katalog wspólnych bibliotek Jabber,3,Brak
start_cmd=Polecenie do uruchomienia jabber,0
stop_cmd=Polecenie do zatrzymania jabber,3,Zabij proces
