line2=Konfigurace systému,11
jabber_config=Jabber XML konfigurační soubor,0
jabber_dir=Jabber základní adresář,0
jabber_spool=Jabber adresář hostů,3,Pod základním adresářem
jabber_lib=Adresář Jabber sdílených knihoven,3,Nic
start_cmd=Příkaz pro spuštění jabberu,0
stop_cmd=Příkaz pro ukončení jabberu,3,Zabít proces
