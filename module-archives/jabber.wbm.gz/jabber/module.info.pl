desc_pl=Jabber IM - serwer
longdesc_pl=Konfiguruj muli-protokołowy serwer wiadomości Jabber.
