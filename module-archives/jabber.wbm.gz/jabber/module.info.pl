desc_pl=Jabber IM - serwer
longdesc_pl=Konfiguruj muli-protoko�owy serwer wiadomo�ci Jabber.
