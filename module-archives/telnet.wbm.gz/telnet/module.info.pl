desc_pl=Logowanie przez SSH
