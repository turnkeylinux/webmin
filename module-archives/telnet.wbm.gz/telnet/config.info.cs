host=Hostname k přípojení,3,Automatické
port=Port k připojení,3,Výchozí
mode=Typ připojení,1,0-Telnet,1-Bezpečný Shell (doporučeno)
sizemode=Velikost appletu,1,0-80x24 znaků (v základním fontu),1-Maximální,2-Vlastní velikost
size=Vlastní šířka x výška,0
fontsize=Velikost fontu v bodech,3,Defaultní
detach=Mód odděleného okna?,1,1-ano,0-ne
no_test=Otestovat telnet nebo SSH server?,1,0-ano,1-ne
