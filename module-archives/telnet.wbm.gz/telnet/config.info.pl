host=Nazwa hosta&#44; z&nbsp;którym łączyć,3,Automatycznie
port=Port&#44; na który łączyć,3,Domyślny
mode=Rodzaj połączenia,1,0-Telnet,1-SSH (zalecane)
sizemode=Rozmiar apletu,1,0-80x24 znaki,1-Dynamiczny
fontsize=Rozmiar fontu w&nbsp;punktach,3,Domyślny
