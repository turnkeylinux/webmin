host=Nazwa hosta&#44; z&nbsp;kt�rym ��czy�,3,Automatycznie
port=Port&#44; na kt�ry ��czy�,3,Domy�lny
mode=Rodzaj po��czenia,1,0-Telnet,1-SSH (zalecane)
script=Skrypt logowania,3,Brak
sizemode=Rozmiar apletu,1,0-80x24 znaki,1-Dynamiczny
fontsize=Rozmiar fontu w&nbsp;punktach,3,Domy�lny
