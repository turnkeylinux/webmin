desc_cs=SSH přihlášení
