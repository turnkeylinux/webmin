desc_pl=Zarz�dzanie drukarkami
longdesc_pl=Tw�rz i edytuj lokalne oraz zdalne drukarki. Wsparcie dla serwer�w drukowania Windows i sterownik�w Ghostscript.
