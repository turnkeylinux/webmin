desc_pl=Zarządzanie drukarkami
longdesc_pl=Twórz i edytuj lokalne oraz zdalne drukarki. Wsparcie dla serwerów drukowania Windows i sterowników Ghostscript.
