desc_pl=Klaster - Serwery Usermin
longdesc_pl=Instaluj i zarz�dzaj modu�ami oraz motywami na wszystkich serwerach Usermin.
