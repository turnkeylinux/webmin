desc_pl=Monitorowanie pasma
longdesc_pl=Raporty na temat wykorzystania transferu przez host, port, protokół w określonym czasie.
