desc_pl=Monitorowanie pasma
longdesc_pl=Raporty na temat wykorzystania transferu przez host, port, protok� w okre�lonym czasie.
