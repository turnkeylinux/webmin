firewall_system=Rodzaj firewalla,4,firewall-IPtables,,ipfw-IPFW,ipfilter-IPFilter,shorewall-Shorewall,-Wykryj automatycznie
bandwidth_log=Plik logu do utworzenia dla komunikatów firewalla,0
bandwidth_dir=Katalog dla danych pasma,3,Domyślny (/etc/webmin/bandwidth/hours)
