at_style=Rodzaj systemu At,1,linux-Linux,solaris-Solaris,freebsd-FreeBSD
at_dir=Katalog zadań At,0
allow_file=Plik dozwolonych użytkowników At,3,Brak
deny_file=Plik zabronionych użytkowników At,3,Brak
