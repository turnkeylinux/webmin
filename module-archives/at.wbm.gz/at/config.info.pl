at_style=Rodzaj systemu At,1,linux-Linux,solaris-Solaris,freebsd-FreeBSD
at_dir=Katalog zada� At,0
allow_file=Plik dozwolonych u�ytkownik�w At,3,Brak
deny_file=Plik zabronionych u�ytkownik�w At,3,Brak
