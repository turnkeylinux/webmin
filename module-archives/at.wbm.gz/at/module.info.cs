desc_cs=Plánované příkazy
