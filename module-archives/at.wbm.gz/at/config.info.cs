at_style=At typ systému,1,linux-Linux,solaris-Solaris,freebsd-FreeBSD,irix-Irix,macos-MacOS X,openserver-OpenServer
at_dir=At adresář úkolů,0
allow_file=Povolit soubor At uživatelů,3,Nic
deny_file=Zakázat soubor At uživatelé,3,Nic
