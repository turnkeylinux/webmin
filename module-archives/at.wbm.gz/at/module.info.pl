desc_pl=Zaplanowane polecenia
longdesc_pl=Harmonogram wykonywania poleceń lub skryptów.
