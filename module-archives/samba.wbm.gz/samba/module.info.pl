desc_pl=Samba - udost�pnianie plik�w dla Windows
longdesc_pl=Tw�rz i edytuj wsp�dzielone przez Samba pliki i drukarki.
