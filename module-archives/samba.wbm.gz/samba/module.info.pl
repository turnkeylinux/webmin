desc_pl=Samba - udostępnianie plików dla Windows
longdesc_pl=Twórz i edytuj współdzielone przez Samba pliki i drukarki.
