desc_cs=Samba - sdílení souborů pro Windows
