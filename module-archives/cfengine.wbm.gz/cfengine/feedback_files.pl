
do 'cfengine-lib.pl';

sub feedback_files
{
return ( $cfengine_conf, $cfd_conf, $cfrun_hosts );
}

1;

