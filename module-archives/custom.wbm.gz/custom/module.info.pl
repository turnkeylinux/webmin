desc_pl=W�asne polecenia
longdesc_pl=Tw�rz przyciski do wykonywania cz�sto u�ywanych polece� lub edytowania plik�w w twoim systemie.
