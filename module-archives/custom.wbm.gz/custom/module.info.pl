desc_pl=Własne polecenia
longdesc_pl=Twórz przyciski do wykonywania często używanych poleceń lub edytowania plików w twoim systemie.
