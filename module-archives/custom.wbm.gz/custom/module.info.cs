desc_cs=Užívatelské příkazy
