display_mode=Na głównej stronie ukazują się,1,0-Wszystkie polecenia i parametry,1-Dowiązania do poleceń
width=Szerokość okna edytora pliku,3,Domyślnie (80 znaków)
height=Wysokość okna edytora pliku,3,Domyślnie (20 znaków)
wrap=Tryb wrap edytora plików,1,-Domyślnie (miękki),hard-Twardy,off-Wyłączone
columns=Kolumny do wyświetlenia poleceń,1,2-2,1-1
sort=Sortuj polecenia według,1,desc-Nazwy,html-Opisu,-kolejności polecenia
params_file=Traktuj domyślne wartości zaczynające się znakiem / jako plik do odczytania,1,1-Tak,0-Nie
params_cmd=Traktuj domyślne wartości kończące się znakiem | jako polecenie do uruchomienia,1,1-Tak,0-Nie
