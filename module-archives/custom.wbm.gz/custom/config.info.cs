display_mode=Hlavní stránka zobrazuje,1,0-Všechny příkazy a parametry,1-Linky k příkazům
width=šířka pro okno editoru souboru,3,Výchozí (80 znaků)
height=Výška pro okno editoru souboru,3,Výchozí (20 znaků)
wrap=Mód pro zalamování řádku v editoru souboru,1,-Výchozí (Lehké),hard-Těžké,off-Vypnuto
