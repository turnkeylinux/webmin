desc_cs=Generátor analýzy Squid
