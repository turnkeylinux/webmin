usermin_dir=Adresář Usermin konfigurace,0
cron_mode=Zobrazit čas aktualizace jako,1,0-Jednoduché rozhraní,1-Výběr času jako v cronu
host=Jméno hosta Userminu pro připojené uživatele,3,Stejné jako u Webminu
port=Port Userminu pro připojené uživatele,3,Zjistit automaticky
