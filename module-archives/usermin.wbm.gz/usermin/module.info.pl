desc_pl=Konfiguracja Usermina
longdesc_pl=Skonfiguruj globalne opcje dla Usermina - serwera zarz�dzania u�ytkownikami
