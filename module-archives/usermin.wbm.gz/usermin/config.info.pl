usermin_dir=Katalog konfiguracyjny Usermina,0
cron_mode=Pokaż czas aktualizacji jako,1,0-Prosty interfejs,1-Cron time selector
host=Nazwa hosta Usermina do przełączania użytkowników,3,Taki sam jak w Webmin
port=Port Usermina do przełączania użytkowników,3,Określony automatycznie
