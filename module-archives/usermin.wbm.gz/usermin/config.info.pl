usermin_dir=Katalog konfiguracyjny Usermina,0
cron_mode=Poka� czas aktualizacji jako,1,0-Prosty interfejs,1-Cron time selector
host=Nazwa hosta Usermina do prze��czania u�ytkownik�w,3,Taki sam jak w Webmin
port=Port Usermina do prze��czania u�ytkownik�w,3,Okre�lony automatycznie
