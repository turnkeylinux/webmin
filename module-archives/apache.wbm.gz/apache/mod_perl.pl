# mod_perl.pl
# Placeholder for mod_perl directives

sub mod_perl_directives
{
return ();
}

sub mod_perl_handlers
{
return ("perl-script");
}

1;
