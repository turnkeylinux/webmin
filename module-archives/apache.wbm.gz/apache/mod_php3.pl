# mod_php3.pl
# Placeholder for mod_php3 directives

sub mod_php3_directives
{
return ();
}

sub mod_php3_handlers
{
return ("php3-script");
}

1;
