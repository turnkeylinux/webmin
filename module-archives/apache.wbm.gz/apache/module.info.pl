desc_pl=Apache - serwer WWW
longdesc_pl=Konfiguracja niemal wszystkich opcji i dyrektyw Apache.
