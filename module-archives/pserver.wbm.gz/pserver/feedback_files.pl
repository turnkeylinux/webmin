
do 'pserver-lib.pl';

sub feedback_files
{
return ( $passwd_file, $readers_file, $writers_file, $cvs_config_file );
}

1;

