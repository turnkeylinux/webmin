desc_pl=Rotacja logów
longdesc_pl=Ustaw automatyczną rotację dla Apache, Squid, Syslog i innych plików logów.
