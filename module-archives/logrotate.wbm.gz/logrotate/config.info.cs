line1=Konfigurovatelné volby,11
sort_mode=Řadit log soubory podle,1,1-jména log souboru,0-pořadí v konfiguračním souboru
add_file=Přidat nové sekce pro rotaci logů do,3,Hlavní konfigurační soubor
line2=Systémová konfigurace,11
logrotate_conf=Cesta ke konfiguračnímu souboru logrotate,0
logrotate=Cesta k programu logrotate,0
