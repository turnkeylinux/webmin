desc_cs=Rotování log souborů
