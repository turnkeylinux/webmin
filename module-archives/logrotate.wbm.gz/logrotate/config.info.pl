line1=Opcje konfiguracyjne,11
sort_mode=Sortuj pliki logów według,1,1-Nazwy,0-Kolejności w pliku konfiguracyjnym
add_file=Dodaj nowe sekcje rotacji logów do,3,Głównego pliku konfiguracyjnego
line2=Konfiguracja systemu,11
logrotate_conf=Ścieżka do pliku konfiguracyjnego logrotate,0
logrotate=Ścieżka do programu logrotate,0
