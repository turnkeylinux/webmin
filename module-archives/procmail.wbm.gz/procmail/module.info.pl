desc_pl=Procmail - filtr e-maili
