line1=Nastavení konfigurace,11
includes=Zobrazit obsah vložených souborů?,1,1-ano,0-ne
line2=Konfigurace systému,11
procmailrc=Cesta k systémovému procmailrc souboru,0
procmail=Cesta k programu procmail,0
