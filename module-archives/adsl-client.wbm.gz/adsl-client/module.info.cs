desc_cs=Klient ADSL
