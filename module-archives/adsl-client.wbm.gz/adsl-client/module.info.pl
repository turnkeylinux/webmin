desc_pl=Klient ADSL
longdesc_pl=Konfigurowanie klienta PPTP z pakietem RP-PPPoE.
