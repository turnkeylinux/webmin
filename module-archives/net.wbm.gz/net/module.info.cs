desc_cs=Konfigurace sítě
