desc_pl=Konfiguracja sieci
longdesc_pl=Konfiguracja uruchamianych i aktywnych interfejs�w, DNS, trasowania i /etc/hosts.
