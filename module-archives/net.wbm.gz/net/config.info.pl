hosts_file=Plik z nazwami i adresami host�w <tt>hosts</tt>,0
ipnodes_file=Plik z nazwami i adresami host�w <tt>hosts</tt> IPv6,0
def_netmask=Domy�lna maska podsieci,0
def_broadcast=Domy�lny adres rozg�aszania,0
def_mtu=Domy�lne MTU,0
