desc_pl=Jezyk i motyw graficzny
longdesc_pl=Pozwala aktualnemu użytkownikowi Webimina na zmianę języka, motywu i hasła (o ile to możliwe).
