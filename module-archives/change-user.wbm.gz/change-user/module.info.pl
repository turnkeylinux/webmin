desc_pl=Jezyk i motyw graficzny
longdesc_pl=Pozwala aktualnemu u�ytkownikowi Webimina na zmian� j�zyka, motywu i has�a (o ile to mo�liwe).
