
do 'qmail-lib.pl';

sub feedback_files
{
return ( $qmail_routes_file, $qmail_virts_file, $qmail_assigns_file );
}

1;

