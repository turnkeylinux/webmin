desc_cs=Konfigurace QMail
