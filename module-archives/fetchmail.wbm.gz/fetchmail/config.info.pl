config_file=Modyfikowany plik konfiguracyjny fetchmaila,3,Pliki <tt>.fetchmailrc</tt> wszystkich u�ytkownik�w
fetchmail_path=�cie�ka do programu <tt>fetchmail</tt>,0
daemon_user=U�ytkownik, jako kt�ry serwer fetchmail jest uruchamiany,0
pid_file=�cie�ka do pliku z&nbsp;numerem PID serwera fetchmail,0
