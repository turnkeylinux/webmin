desc_cs=Procházení pošty přes FetchMail
