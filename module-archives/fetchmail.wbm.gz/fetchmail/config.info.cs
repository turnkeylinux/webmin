line1=Nastavení konfigurace,11
config_file=Fetchmail konfigurační soubor k editování,3,Všechny uživatelské .fetchmailrc soubory
daemon_user=Uživatel pod kterým je spuštěn fetchmail démon,0
mda_command=Příkaz pro odesílání mailu,3,Použít SMTP
line2=Konfigurace systému,11
fetchmail_path=Cesta k programu fetchmail,0
pid_file=Cestta k PID souboru fetchmail démona,0
