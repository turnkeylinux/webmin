desc_pl=BIND - serwer DNS
longdesc_pl=Twórz i edytuj domeny, rekordy DNS, opcje BIND i widoki.
