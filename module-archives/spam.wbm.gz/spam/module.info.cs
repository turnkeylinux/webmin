desc_cs=Spamový filtr SpamAssassin
