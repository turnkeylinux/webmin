date_subs=Podstawić <tt>strftime</tt> jako lokalizację kopii zapasowych?,1,1-Tak,0-Nie
webmin_subs=Uczyń zmienną Webmina jako substytut dla celu kopii zapasowej?,1,1-Tak,0-Nie
smtp_server=Wyślij e-mail przez serwer SMTP,3,Moduł Czytaj e-maile użytkowników
run_mode=Uruchom kopie zapasowe w,1,0-pierwszym planie (Foreground),1-tle (Background)
nonewtape=Działanie jeżeli taśma jest pełna,1,1-Natychmiast przerwij,0-Poproś o nową taśmę
always_tar=Zawsze używać formatu TAR do kopii zapasowych?,1,1-Tak,0-Nie
error_email=Wyślij e-mail o kopii zapasowej,1,0-Zawsze,1-Tylko w przypadku błędu
simple_sched=Format wybierania harmonogramu,1,1-Prosty,0-Pełny
