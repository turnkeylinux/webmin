date_subs=Podstawi� <tt>strftime</tt> jako lokalizacj� kopii zapasowych?,1,1-Tak,0-Nie
webmin_subs=Uczy� zmienn� Webmina jako substytut dla celu kopii zapasowej?,1,1-Tak,0-Nie
smtp_server=Wy�lij e-mail przez serwer SMTP,3,Modu� Czytaj e-maile u�ytkownik�w
run_mode=Uruchom kopie zapasowe w,1,0-pierwszym planie (Foreground),1-tle (Background)
nonewtape=Dzia�anie je�eli ta�ma jest pe�na,1,1-Natychmiast przerwij,0-Popro� o now� ta�m�
always_tar=Zawsze u�ywa� formatu TAR do kopii zapasowych?,1,1-Tak,0-Nie
error_email=Wy�lij e-mail o kopii zapasowej,1,0-Zawsze,1-Tylko w przypadku b��du
simple_sched=Format wybierania harmonogramu,1,1-Prosty,0-Pe�ny
