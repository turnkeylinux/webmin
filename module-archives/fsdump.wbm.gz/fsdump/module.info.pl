desc_pl=Kopia zapasowa systemu plik�w
longdesc_pl=Tw�rz i przywracaj kopie zapasowe systemu plik�w
