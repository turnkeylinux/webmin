desc_cs=Softwarové balíčky
