package_system=Balíčky systémové správy,1,rpm-RPM,pkgadd-Solaris,hpux-HPUX,freebsd-FreeBSD,slackware-Slackware,debian-Debian,aix-AIX,emerge-Gentoo
update_system=Systém pro aktualizaci balíčků,1,-Detekovat automaticky,apt-APT,yum-YUM,rhn-Redhat Network,csw-Blastwave,urpmi-URPMI,emerge-Emerge
apt_mode=Příkaz pro užití APT instalace,1,0-apt&#45;get,1-aptitute
