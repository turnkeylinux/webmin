desc_pl=Pakiety oprogramowania
longdesc_pl=Zarządzaj pakietami oprogramowania w twoim systemie i instaluj nowe pakiety.
