desc_cs=Správa logických svazků
