desc_cs=PPTP VPN server
