desc_pl=RAID w&nbsp;Linuksie
