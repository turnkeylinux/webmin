desc_pl=RAID w Linuksie
