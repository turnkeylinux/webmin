raidtab=Plik konfiguracji RAIDu,0
mdstat=Plik stanu RAIDu w&nbsp; kernelu,0
