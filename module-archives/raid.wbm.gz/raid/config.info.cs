line1=Konfigurovatelné volby,11
refresh=Počet sekund mezi obnovením stavu RAIDu,3,Nikdy
line2=Konfigurace systému,11
raidtab=Konfigurační soubor RAIDu,0
mdadm=Konfigurační soubor MDADM,0
mdstat=RAID stavový soubor jádra,0
