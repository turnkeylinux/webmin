sort_mode=Sortuj hosty według,1,1-Nazwy,0-Kolejności dodania,2-Opisu
table_mode=Wyświetl hosty jako,1,1-Tabela,0-Ikony
