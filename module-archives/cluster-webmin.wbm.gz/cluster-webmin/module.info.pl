desc_pl=Klaster - Serwery Webmin
longdesc_pl=Instaluj i zarz�dzaj modu�ami, szablonami, u�ytkownikami, grupami i kontrol� dost�pu na wszystkich serwerach Webmina.
