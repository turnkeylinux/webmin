desc_pl=Klaster - Serwery Webmin
longdesc_pl=Instaluj i zarządzaj modułami, szablonami, użytkownikami, grupami i kontrolą dostępu na wszystkich serwerach Webmina.
