desc_pl=Nagrywarka CD
longdesc_pl=Nagrywaj dane na CD z obraz�w ISO lub wybranych katalog�w.
