pap_file=Plik haseł PAP,0
encrypt_pass=Szyfrować hasła w&nbsp; pliku,1,1-Tak,0-Nie
