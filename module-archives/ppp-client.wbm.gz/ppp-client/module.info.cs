desc_cs=PPP Dialup klient
