
require 'ldap-client-lib.pl';

sub cpan_recommended
{
return ( "Net::LDAP" );
}

