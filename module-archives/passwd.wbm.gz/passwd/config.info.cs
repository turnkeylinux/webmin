max_users=Nejvyšší počet zobrazených uživatelů,0
input_type=Typ výběru uživatele,1,1-Seznam položek,0-Textové pole
sort_mode=Setřídit uživatele podle,1,0-Pořadí v souboru,1-Uživatelského jména
passwd_cmd=Příkaz pro změnu hesla,3,Změnit přímo systémové soubory
