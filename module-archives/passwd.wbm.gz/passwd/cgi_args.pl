
do 'passwd-lib.pl';

sub cgi_args
{
my ($cgi) = @_;
if ($cgi eq 'edit_passwd.cgi') {
	if ($access{'mode'} == 0) {
		# Can edit any user, so do root
		return 'user=root';
		}
	elsif ($access{'mode'} == 1) {
		# Edit first allowed user
		local @u = split(/\s+/, $access{'users'});
		return 'user='.&urlize($u[0]);
		}
	elsif ($access{'mode'} == 3) {
		# Edit current user
		return 'user='.$remote_user.'&one=1';
		}
	else {
		# Too hard to find a valid user
		return 'none';
		}
	}
return undef;
}
