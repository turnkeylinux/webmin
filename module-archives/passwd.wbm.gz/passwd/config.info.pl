max_users=Maksymalna liczba pokazywanych u�ytkownik�w,0
input_type=Spos�b wyboru u�ytkownika,1,1-Okienko wyboru,0-Pole tekstowe
sort_mode=Porz�dkowa� u�ytkownik�w wed�ug,1,0-Kolejno�ci w&nbsp;zbiorze,1-Nazwy u�ytkownika

