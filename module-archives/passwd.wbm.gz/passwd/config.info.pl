max_users=Maksymalna liczba pokazywanych użytkowników,0
input_type=Sposób wyboru użytkownika,1,1-Okienko wyboru,0-Pole tekstowe
sort_mode=Porządkować użytkowników według,1,0-Kolejności w&nbsp;zbiorze,1-Nazwy użytkownika
