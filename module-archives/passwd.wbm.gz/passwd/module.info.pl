desc_pl=Zmiany hase�
