line2=Konfigurace systému,11
stunnel_path=Cesta ke spouštěči stunnelu,0
