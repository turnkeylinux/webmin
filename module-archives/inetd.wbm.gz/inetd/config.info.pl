inetd_conf_file=Plik konfiguracyjny inetd,0
inetd_dir=Katalog konfiguracyjny inetd,3,Brak
extended_inetd=Rozszerzona obs�uga inetd,1,0-Pierwotna,1-Podstawowa,2-Wzbogacona
show_empty=Pokazywa� us�ugi bez programu,1,1-Tak,0-Nie
rpc_inetd=Inetd obs�uguje programy RPC,1,1-Tak,0-Nie
ipv6=Wspomaganie dla us�ug IPv6,1,1-Tak,0-Nie
sort_mode=Porz�dek us�ug i&nbsp;program�w,1,0-Porz�dek w&nbsp;plku,1-Wg nazwy,2-Assignment
services_file=Plik us�ug sieciowych,0
rpc_file=Plik us�ug RPC,0
protocols_file=Plik protoko��w sieciowych,0
rpc_protocols=Podprotoko�y RPC,0
restart_command=Polecenie restartuj�ce inetd,0
tcpd_path=Pe�na �cie�ka do tcpd,3
allow_file=Pe�na �cie�ka do pliku <tt>allow</tt> dla tcpd,3
deny_file=Pe�na �cie�ka do pliku <tt>deny</tt> dla tcpd,3

