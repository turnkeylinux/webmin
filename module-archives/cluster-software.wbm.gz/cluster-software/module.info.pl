desc_pl=Klaster - Pakiety oprogramowania
longdesc_pl=Instaluj pakiety RPM, debian i Solaris na wielu serwerach z jednego źródła.
