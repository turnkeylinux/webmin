desc_cs=Cluster - Softwarové balíčky
