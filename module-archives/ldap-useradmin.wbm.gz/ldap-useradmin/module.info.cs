desc_cs=LDAP uživatelé a skupiny
