desc_pl=Klaster - Harmonogram zadań (Cron)
longdesc_pl=Twórz zaplanowane zadania Cron, które zosataną uruchomione na wielu serwerach równocześnie.
