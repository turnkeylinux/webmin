desc_pl=Klaster - Harmonogram zada� (Cron)
longdesc_pl=Tw�rz zaplanowane zadania Cron, kt�re zosatan� uruchomione na wielu serwerach r�wnocze�nie.
