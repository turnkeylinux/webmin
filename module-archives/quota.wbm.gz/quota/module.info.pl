desc_pl=Przydziały (Quota) dysków
