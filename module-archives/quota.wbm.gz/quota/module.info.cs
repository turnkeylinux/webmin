desc_cs=Diskové kvóty
