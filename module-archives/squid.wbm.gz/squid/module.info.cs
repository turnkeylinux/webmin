desc_cs=Squid proxy server
