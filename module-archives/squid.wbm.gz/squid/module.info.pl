desc_pl=Serwer proxy Squid
