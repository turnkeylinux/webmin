desc_pl=Tryb tekstowy (konsola)
longdesc_pl=Dost�p do pow�oki systemowej bez konieczno�ci u�ywania oddzielnego klienta SSH, u�ywaj�c Ajaxterm
