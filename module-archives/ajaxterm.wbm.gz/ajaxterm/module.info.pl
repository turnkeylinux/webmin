desc_pl=Tryb tekstowy (konsola)
longdesc_pl=Dostęp do powłoki systemowej bez konieczności używania oddzielnego klienta SSH, używając Ajaxterm
