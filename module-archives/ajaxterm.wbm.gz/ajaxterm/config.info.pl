autologin=Tryb logowania,1,0-Popro� o login i has�o,1-Otw�rz root shell
timeout=Czas oczekiwania w trybie idle przed zamkni�ciem po��czenia,0,5,,sekund
