autologin=Tryb logowania,1,0-Poproś o login i hasło,1-Otwórz root shell
timeout=Czas oczekiwania w trybie idle przed zamknięciem połączenia,0,5,,sekund
