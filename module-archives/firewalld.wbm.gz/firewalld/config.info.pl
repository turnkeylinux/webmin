firewall_cmd=Pełna ścieżka do programu firewall-cmd,0
init_name=Nazwa skryptu init FirewallD,0
