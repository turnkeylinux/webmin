firewall_cmd=Pe�na �cie�ka do programu firewall-cmd,0
init_name=Nazwa skryptu init FirewallD,0
