desc_pl=FirewallD
longdesc_pl=Konfiguracja Firewalla Linuksa u�ywaj�c FirewallD, poprzez edytowanie dozwolonych us�ug i port�w.
