desc_pl=FirewallD
longdesc_pl=Konfiguracja Firewalla Linuksa używając FirewallD, poprzez edytowanie dozwolonych usług i portów.
