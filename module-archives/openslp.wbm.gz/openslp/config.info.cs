line2=Konfigurace systému,11
slpd_conf=Cesta ke konfiguračnímu souboru OpenSLP,0
slpd_reg=Cesta k registračnímu souboru OpenSLP,0
slpd_log=Cesta k log souboru OpenSLP,0
slpd_pid=Cesta k OpenSLP PID souboru,0
slpd=Cesta ke spouštěči OpenSLP démona,0
start_cmd=Příkaz pro spuštění OpenSLP,3,Démon právě běží
stop_cmd=Příkaz pro ukončení OpenSLP,3,Zabít proces
