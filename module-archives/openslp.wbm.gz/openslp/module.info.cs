desc_cs=OpenSLP server
