desc_pl=NFS - eksport
longdesc_pl=Edytuj udost�pnione pliki NFS zdefinowane w /etc/exports.
