line2=Konfigurace systému,11
exports_file=Soubor exportovaných souborových systémů,0
restart_command=Příkaz pro restratovní serveru exportu,0
