dfstab_file=Lokalizacja pliku 'exports' NFS-u,0
fstypes_file=Rodzaj wsp�dzielonego systemu plik�w,3,Brak
share_all_command=Polecenie w��czaj�ce wsp�dzielenie,0
unshare_all_command=Polecenie wy��czaj�ce wsp�dzielenie,0
