# pam_rootok.so has no UI

$module_has_no_args = 1;

