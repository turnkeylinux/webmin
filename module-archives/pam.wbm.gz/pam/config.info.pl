pam_dir=Katalog konfiguracji PAM,0
ignore=Pliki ignorowane w katalogu PAM,0
lib_dirs=Katalogi zawierające biblioteki PAM,0
mod_equiv=Równoważne moduły PAM,0
