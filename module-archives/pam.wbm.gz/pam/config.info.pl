pam_dir=Katalog konfiguracji PAM,0
ignore=Pliki ignorowane w katalogu PAM,0
lib_dirs=Katalogi zawieraj�ce biblioteki PAM,0
mod_equiv=R�wnowa�ne modu�y PAM,0
