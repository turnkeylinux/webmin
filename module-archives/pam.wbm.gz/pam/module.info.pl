desc_pl=Autoryzacja przez PAM
