line2=Konfigurace systému,11
pam_dir=Adresář PAM konfigurace,0
ignore=Ignorované soubory v PAM adresáři,0
lib_dirs=Adresáře obsahující PAM knihovny,0
mod_equiv=Ekvivalentní PAM moduly,0
