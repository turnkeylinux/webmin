
require 'pam-lib.pl';

sub cpan_recommended
{
return ( "Authen::PAM" );
}

