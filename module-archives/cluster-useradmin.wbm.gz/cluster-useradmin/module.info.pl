desc_pl=Klaster - Użytkownicy i grupy
longdesc_pl=Twórz, aktualizuj i usuwaj użytkowników i grupy na wielu serwerach. Inaczej niż w NIS, każdy serwer ma własny plik hasła i grupy, który jest zdalnie aktualizowany przez ten moduł.
