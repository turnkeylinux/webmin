desc_cs=Cluster - Uživatelé a skupiny
