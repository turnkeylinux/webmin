desc_pl=Serwer poczty głosowej
