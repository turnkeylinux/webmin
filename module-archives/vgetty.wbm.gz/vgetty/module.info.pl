desc_pl=Serwer poczty g�osowej
