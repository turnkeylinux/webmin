line2=Konfigurace systému,11
vgetty_cmd=Cesta k vgetty programu,0
vgetty_config=Cesta ke konfiguračnímu souboru vgetty,0
