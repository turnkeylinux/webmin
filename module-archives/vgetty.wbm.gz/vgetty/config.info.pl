line2=Konfiguracja systemu,11
vgetty_cmd= �cie�ka do programu vgetty ,0
vgetty_config=�cie�ka do pliku konfiguracyjnego vgetty,0
