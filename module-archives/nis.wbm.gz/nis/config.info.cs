line1=Možnosti konfigurace,11
max_size=Maximální počet zobrazených záznamů,0
manual_build=Přestavět NIS mapy automaticky?,1,0-ano,1-ne
line2=Konfigurace systému,11
client_conf=Konfigurační soubor NIS klienta,0
nsswitch_conf=Přepínací soubor NIS klienta,0
securenets=Důvěrné síťové soubory,3,Žádné
