desc_pl=NIS - klient i serwer
longdesc_pl=Ustaw system jako klient NIS. Uwaga: NIS+ nie jest obs�ugiwany.
