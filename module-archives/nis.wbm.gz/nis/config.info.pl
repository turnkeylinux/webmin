line1=Opcje konfiguracyjne,11
max_size=Maksymalna liczba pokazywanych rekord�w,0
manual_build=Automatycznie przebudowywa� tabele NIS?,1,0-Tak,1-Nie
line2=Konfiguracja systemu,11
client_conf=Plik konfiguracyjny klienta NIS,0
nsswitch_conf=Plik &quot;nsswitch&quot; klienta NIS,0
securenets=Plik zaufanych sieci,3,Brak
