line1=Opcje konfiguracyjne,11
max_size=Maksymalna liczba pokazywanych rekordów,0
manual_build=Automatycznie przebudowywać tabele NIS?,1,0-Tak,1-Nie
line2=Konfiguracja systemu,11
client_conf=Plik konfiguracyjny klienta NIS,0
nsswitch_conf=Plik "nsswitch" klienta NIS,0
securenets=Plik zaufanych sieci,3,Brak
