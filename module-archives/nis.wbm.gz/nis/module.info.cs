desc_cs=NIS klient a server
