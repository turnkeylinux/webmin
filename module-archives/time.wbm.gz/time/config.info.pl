line1=Konfigurowalne opcje,11
lease=Dozwolona liczba sekund różnicy pomiędzy czasem systemowym i&nbsp;sprzętowym,0
timeserver=Domyślny serwer czasu,3,Brak
ntp_only=Użyć tylko NTP do synchronizacji czasu?,1,1-Tak,0-Nie
line2=Konfiguracja systemu,11
seconds=Format dla ustawiania czasu systemowego,1,1-MMDDGGMMRRRR.SS,0-MMDDGGMMRR,2-RRRRMMDDGGMM.SS
zone_style=Metoda konfiguracji strefy czasowej,4,linux-Linux,freebsd-FreeBSD,solaris-Solaris,-&lt;Nie obsługiwany na tym systemie operacyjnym&gt;
hwclock_flags=Flagi linii poleceń dla hwclock,10,-Brak,sysconfig-Z /etc/sysconfig/clock
