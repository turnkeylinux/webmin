lease=Dozwolona liczba sekund r�nicy pomi�dzy czasem systemowym i&nbsp;sprz�towym,0
timeserver=Domy�lny serwer czasu,3,Brak
hwtime=System obs�uguje czas sprz�towy,1,1-Tak,0-Nie
seconds=Format dla ustawiania czasu systemowego,1,1-MMDDGGMMRRRR.SS,0-MMDDGGMMRR,2-RRRRMMDDGGMM.SS
zonelink=Plik opisu strefy czasowej,0
zonetab=Plik z&nbsp;list� stref czasowych,0
zonedir=Katalog z&nbsp;plikami opisu stref czasowych,0
