line1=Konfigurowalne opcje,11
lease=Dozwolona liczba sekund r�nicy pomi�dzy czasem systemowym i&nbsp;sprz�towym,0
timeserver=Domy�lny serwer czasu,3,Brak
ntp_only=U�y� tylko NTP do synchronizacji czasu?,1,1-Tak,0-Nie
line2=Konfiguracja systemu,11
seconds=Format dla ustawiania czasu systemowego,1,1-MMDDGGMMRRRR.SS,0-MMDDGGMMRR,2-RRRRMMDDGGMM.SS
zone_style=Metoda konfiguracji strefy czasowej,4,linux-Linux,freebsd-FreeBSD,solaris-Solaris,-&lt;Nie obs�ugiwany na tym systemie operacyjnym&gt;
hwclock_flags=Flagi linii polece� dla hwclock,10,-Brak,sysconfig-Z /etc/sysconfig/clock
