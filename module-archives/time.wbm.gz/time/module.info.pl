desc_pl=Czas systemowy 
longdesc_pl=Ustaw czas systemowy i sprz�towy r�cznie lub z serwera czasu.
