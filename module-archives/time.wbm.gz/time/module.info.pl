desc_pl=Czas systemowy 
longdesc_pl=Ustaw czas systemowy i sprzętowy ręcznie lub z serwera czasu.
