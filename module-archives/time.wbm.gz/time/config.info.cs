line1=Možnosti konfigurace,11
lease=Akceptovatelná prodleva (ve vteřinách) mezi systémovým a harwarovým časem,0
timeserver=Výchozí čas serveru,3,Nic
ntp_only=Použít pouze NTP pro časovou synchronizaci?,1,1-Ano,0-Ne
line2=Konfigurace systému,11
seconds=Formát nastavení systémového času,1,1-MMDDHHMMYYYY.SS,0-MMDDHHMMYY,2-YYYYMMDDHHMM.SS
zone_style=Metoda konfigurace časové zóny,4,linux-Linux,freebsd-FreeBSD,solaris-Solaris,-&lt;Není v tomto OS podporován&gt;
hwclock_flags=Signály příkazového řádku pro hw hodiny,10,-Nic,sysconfig-Z /etc/sysconfig/clock
