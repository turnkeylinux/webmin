desc_cs=Systémový čas
