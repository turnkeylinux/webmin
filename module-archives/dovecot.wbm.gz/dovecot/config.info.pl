dovecot=Lokalizacja Dovecot,0
dovecot_config=Pe�na �cie�ka do pliku konfiguracyjnego Dovecot,0
init_script=Nazwa skryptu init Dovecota,3,Nie istnieje
pid_file=Plik PID serwera Dovecot,0
