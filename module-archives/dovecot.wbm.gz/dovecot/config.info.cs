dovecot=Program Dovecot serveru,0
dovecot_config=Úplná cesta ke konfiguračnímu souboru Dovecot,0
init_script=Název skiptu Dovecot inicializace,3,Žádný neexistuje
pid_file=PID soubor Dovecot serveru,0
