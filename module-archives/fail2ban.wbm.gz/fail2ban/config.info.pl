config_dir=Katalog konfiguracji Fail2Ban,0
client_cmd=Pe�na �cie�ka do polecenia fail2ban-client,0
server_cmd=Pe�na �cie�ka do polecenia fail2ban-server,0
init_script=Nazwa akcji uruchamiania przy starcie,3,Nie skonfigurowano
