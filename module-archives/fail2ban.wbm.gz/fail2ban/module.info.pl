desc_pl=Fail2Ban - detektor intruzów
longdesc_pl=Fail2Ban chroni twój system przed atakami typu Brute Force przez wykrywanie i blokowanie źródłowego IP.
