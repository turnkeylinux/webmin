desc_pl=Fail2Ban - detektor intruz�w
longdesc_pl=Fail2Ban chroni tw�j system przed atakami typu Brute Force przez wykrywanie i blokowanie �r�d�owego IP.
