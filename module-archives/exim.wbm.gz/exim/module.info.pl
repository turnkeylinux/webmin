desc_pl=Exim - serwer poczty
