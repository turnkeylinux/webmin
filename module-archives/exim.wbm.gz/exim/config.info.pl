exim_dir=Katalog Exim,0
exim_virt_dir=Aliasy katalogu Exim,0
exim_addrfile=Plik lokalnych domen Exim,3,
exim_aliasfileext=Rozszerzenie pliku aliasów domeny Exim,3,
exim_dbmfile=Plik lokalnych domen Exim,3,
exim_dbmext=Rozszerzenie mapowania domen lokalnych Exim,3,
mail_system=Tworzyć mbox lub maildir dla nowych użytkowników?,1
exim_mail_file=Nsxes pliku mbox lub katalogu maildir,0
