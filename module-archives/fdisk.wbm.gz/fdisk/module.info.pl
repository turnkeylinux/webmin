desc_pl=Partycje na lokalnych dyskach
