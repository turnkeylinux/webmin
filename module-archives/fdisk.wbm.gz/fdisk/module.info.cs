desc_cs=Oddíly na lokálních discích
