sort_mode=Sortuj kopie komend wed�ug,1,0-Utworzenia,1-Nazwy pliku,2-Serwer�w docelowych
