desc_cs=Cluster - Kopírování souborů
