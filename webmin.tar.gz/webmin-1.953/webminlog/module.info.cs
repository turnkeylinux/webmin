desc_cs=Záznamy činnosti ve Webminu
