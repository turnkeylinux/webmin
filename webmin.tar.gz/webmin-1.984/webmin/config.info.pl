standard_url=URL listy modułów standardowych,3,www.webmin.com
third_url=URL listy modułów osób trzecich,3,www.webmin.com
cron_mode=Pokazuj czasy aktualizacji jako,1,0-Prosty,1-Ustawienia czasu Crona
warn_days=Na ile dni przed wygaśnięciem hasła ostrzegać użytkowników?,0,5
