desc_pl=Działające procesy
