line1=Možnosti konfigurace,11
resolve=Přeložit nalezené adresy serverů?,1,1-ano,0-ne
scan_time=Časová prodleva pro scanování reakcí,0
display_mode=Ukázat servery jako,1,1-tabulku,0-ikony
sort_mode=Seřadit servery podle,1,4-IP adres,1-jména host,2-popisu,3-OS,5-skupiny,0-pořadí vzniku
show_status=Ukázat stav serverů?,1,1-ano,0-ne
line2=SKonfigurace systému,11
groups_dir=Adresář MSC cluster skupin,0
