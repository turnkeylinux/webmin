desc_cs=Spuštěné procesy
