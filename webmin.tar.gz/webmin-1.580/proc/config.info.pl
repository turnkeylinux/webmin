default_mode=Domy�lny spos�b wy�wietlania proces�w,4,last-Ostatnio wybrany,tree-Drzewo proces�w,user-Porz�dek wg u�ytkownika,size-Porz�dek wg rozmiaru,cpu-Porz�dek wg CPU,search-Formularz szukania,run-Formularz uruchomienia
ps_style=Styl wyj�cia polecenia PS,1,sysv-SYSV,linux-Linux,hpux-HPUX,freebsd-FreeBSD,macos-MacOS
