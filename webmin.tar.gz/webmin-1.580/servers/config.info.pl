resolve=Rozwi�zywa� znalezione adresy serwer�w,1,1-Tak,0-Nie
scan_time=Czas oczekiwania na wynik skanowania,0
