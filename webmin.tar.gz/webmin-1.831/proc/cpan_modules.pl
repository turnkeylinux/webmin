
require 'proc-lib.pl';

sub cpan_recommended
{
return ( "IO::Pty" );
}

