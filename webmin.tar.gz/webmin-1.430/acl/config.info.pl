ssleay=Scie�ka do programu openssl lub ssleay,0
select=Wy�wietl modu�y u�ytkownika w,1,0-Tabeli,1-Rozwijalnym menu
order=Porz�dkuj u�ytkownik�w i&nbap;grupy wg,1,0-Kolejno�ci w&nbsp;zbiorze,1-Nazwy
