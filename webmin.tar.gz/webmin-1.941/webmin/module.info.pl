desc_pl=Konfiguracja Webmina
longdesc_pl=Skonfiguruj Webmina dla siebie przez np. ustawienie dozwolonych host�w, SSL instalowanie modu��w i szablon�w.
