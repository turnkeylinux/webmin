desc_cs=Konfigurace Webminu
