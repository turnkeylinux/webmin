standard_url=URL seznamu standardních modulů,3,Na www.webmin.com
third_url=URL seznamu modulů třetích stran,3,Na www.webmin.com
cron_mode=Zobrazit aktualizační časy jako,1,0-Jednoduché rozhraní,1-Výběr šasu jako u Cronu
