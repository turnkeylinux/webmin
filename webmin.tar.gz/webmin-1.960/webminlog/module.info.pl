desc_pl=Logi Webmina
longdesc_pl=Zobacz szczegółowe dzienniki działań użytkowników Webmina.
