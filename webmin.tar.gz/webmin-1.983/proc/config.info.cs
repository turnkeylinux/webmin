line1=Možnosti konfigurace,11
default_mode=Výchozí styl seznamu procesů,4,last-Poslední změna,tree-Strom peocesů,user-Pořadí podle uživatele,size-Pořadí podle velikosti,cpu-Pořadí v CPU,search-Vyhledávací formulář,run-Spouštěcí formulář
cut_length=Znaky usekávající příkazy na,3,Neomezeno
trace_java=Zobrazit trasování systémových volání využívající,1,1-Java applet,0-Text
line2=Konfigurace systému,11
ps_style=Styl výstupu PS příkazu,1,sysv-SYSV,linux-Linux,hpux-HPUX,freebsd-FreeBSD,macos-MacOS,openbsd-OpenBSD
