# uninstall.pl
# Called when webmin is uninstalled

require 'awstats-lib.pl';

sub module_uninstall
{




}

1;

