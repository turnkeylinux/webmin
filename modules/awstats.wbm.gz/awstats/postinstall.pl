
require 'awstats-lib.pl';

sub module_install
{



}

1;

