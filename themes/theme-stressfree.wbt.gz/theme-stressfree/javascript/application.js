var webminpath = '';
var searchVisible = false;

function initialize(path) {
	webminpath = path;
	
	var prev_onload = window.onload;	window.onload = function() { 		if(prev_onload!=null){ 
			prev_onload();
		} 		if(NiftyCheck()) {    		Rounded("div#container","tr tl","#476DAB","#FFF","smooth");    		Rounded("div#contentcontainer","tr tl","#000","#FFF","smooth"); 		} 		loadSidebar();
	}}

function loadSidebar() {
	if(Cookie.get('sidebar') == 'true') {
		// Display the sidebar
		displaySidebar();	
	}	
}

function switchSidebar() {
	var sidebarClass = $('sidebar').className;
	var visible = true;
	
	if(sidebarClass == 'sidebar-hidden') {
		visible = false;
	}		if(!visible) {
		// Display the sidebar
		displaySidebar();
	} else {
		// Hide the sidebar
		hideSidebar();	
	}
}

function displaySidebar() {
	// Display the systats sidebar div
	refreshSidebar();
    Cookie.set('sidebar','true', 365);
	$('sidebar').className = 'sidebar-visible';
	$('sysstats-open').style.display = 'none';
}

function hideSidebar() {
	// Hide the systats sidebar div
	Cookie.set('sidebar','false', 365);
	$('sidebar').className = 'sidebar-hidden';
	$('sysstats-open').style.display = 'block';
}

function refreshSidebar() {
	// Load the systats into the sidebar div
	var sidebarUrl = webminpath + '/sysstats.cgi';    new Ajax.Updater('sidebar-info', sidebarUrl, {asynchronous:true});
}

function viewSearch() {
	if(!searchVisible) {
		$('searchbutton').style.background = 'url(' + webminpath + '/theme-stressfree/images/searchselected.jpg)';
		$('searchform').style.display = 'block';
		$('searchfield').focus();
		searchVisible = true;
	} else {
		$('searchbutton').style.background = 'url(' + webminpath + '/theme-stressfree/images/searchnotselected.gif)';
		$('searchform').style.display = 'none';
		searchVisible = false;
	}
	return false;
}

function openUrl() {
	// Open the url specified by the selected search result
	var url = webminpath + '/' + $('searchfield').value;
	document.location.href = url;
}

function donateHide() {
	// Load the donate page into the donation div
	var donateUrl = webminpath + '/donate.cgi';
	new Ajax.Updater('donation', donateUrl, {asynchronous:true});
}


// Prototype/Cookie code from http://gorondowtl.sourceforge.net/wiki/Cookie
var Cookie = {  set: function(name, value, daysToExpire) {    var expire = '';    if (daysToExpire != undefined) {      var d = new Date();      d.setTime(d.getTime() + (86400000 * parseFloat(daysToExpire)));      expire = '; expires=' + d.toGMTString();    }    return (document.cookie = escape(name) + '=' + escape(value || '') + expire);  },  get: function(name) {    var cookie = document.cookie.match(new RegExp('(^|;)\\s*' + escape(name) + '=([^;\\s]*)'));    return (cookie ? unescape(cookie[2]) : null);  },  erase: function(name) {    var cookie = Cookie.get(name) || true;    Cookie.set(name, '', -1);    return cookie;  },  accept: function() {    if (typeof navigator.cookieEnabled == 'boolean') {      return navigator.cookieEnabled;    }    Cookie.set('_test', '1');    return (Cookie.erase('_test') === '1');  }};
